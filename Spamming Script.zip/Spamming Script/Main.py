import os
import pyautogui
import webbrowser
import time


message = input("What message would you like to spam?")
repeats = int(input("How much times would you like to send this message?"))
delay = int(input("How many delay would you like between each message?"))

isLoaded = input("Press enter when you are ready to spam!")


print("You have 5 secs before the spammer starts")

time.sleep(5)

for i in range(0, repeats):
    if message != "":
        pyautogui.typewrite(message)
        pyautogui.press("enter")
    else:
        pyautogui.hotkey('ctrl', 'v')
        pyautogui.enter("enter")

    time.sleep(delay/1000)

print("Finished\n")
